﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatchingCards
{
    public partial class Game : Form
    {
        private static int GAME_WIDTH = 4;
        private static int GAME_HEIGHT = 4;

        private StartForm startForm;

        private Card[,] cards = new Card[GAME_WIDTH, GAME_HEIGHT];
        private Dictionary<Tuple<int, int>, Tuple<int, int>> matches = 
            new Dictionary<Tuple<int, int>, Tuple<int, int>>();
        private int matchesCount = 0;

        private static Random random = new Random();

        private Card selected = null, selected2 = null;
        private BoolWrapper freeze = new BoolWrapper(false);
        private Timer freezeTimer = new Timer();

        private static int GAME_TIME = 50000; // 50 de secunde
        private Timer updateTimeTimer = new Timer();
        private int seconds = GAME_TIME / 1000;

        public Game(StartForm startForm)
        {
            InitializeComponent();

            this.startForm = startForm;
            timeLabel.Text = "Timp ramas: " + seconds.ToString() + " secunde";
            completedLabel.Text = 
                "Completate: 0/" + 
                GAME_WIDTH * GAME_HEIGHT;

            freezeTimer.Interval = 1000;
            freezeTimer.Tick += FreezeDone;

            updateTimeTimer.Interval = 1000;
            updateTimeTimer.Tick += UpdateTime;
            updateTimeTimer.Start();

            cardsGrid.RowCount = GAME_WIDTH;
            cardsGrid.ColumnCount = GAME_WIDTH;

            List<Tuple<int, int>> coordinates = new List<Tuple<int, int>>();
            for (int i = 0; i < GAME_WIDTH; i++)
                for (int j = 0; j < GAME_HEIGHT; j++)
                {
                    var coordinate = new Tuple<int, int>(i, j);
                    coordinates.Add(coordinate);
                    cards[i, j] = new Card(coordinate, freeze);
                    cards[i, j].Tag = "Card" + i.ToString() + "," + j.ToString();
                    cards[i, j].Selected += CardSelected;
                    cards[i, j].Dock = DockStyle.Fill;
                    cardsGrid.Controls.Add(cards[i, j]);
                }
            coordinates = coordinates.OrderBy(_ => random.Next()).ToList(); // amestecare

            int card = 0;
            for (int i = 0; i < GAME_WIDTH * GAME_HEIGHT; i += 2)
            {
                cards[coordinates[i].Item1, coordinates[i].Item2]
                    .CardImage = Image.FromFile(Card.CARDS[card]);
                cards[coordinates[i + 1].Item1, coordinates[i + 1].Item2]
                    .CardImage = Image.FromFile(Card.CARDS[card++]);
                matches[coordinates[i]] = coordinates[i + 1];
                matches[coordinates[i + 1]] = coordinates[i];
            }
        }

        private void CardSelected(Card card)
        {
            if (selected == null)
            {
                selected = card;
                return;
            }

            if (selected == card)
            {
                selected = null;
                return;
            }

            if (matches[selected.Coordinates] == card.Coordinates)
            {
                selected.Disabled = true;
                card.Disabled = true;
                selected = null;
                matchesCount += 2;
                completedLabel.Text = 
                    "Completate: " + 
                    matchesCount.ToString() + 
                    "/" + 
                    (GAME_WIDTH * GAME_HEIGHT).ToString();
                if (matchesCount == GAME_WIDTH * GAME_HEIGHT)
                {
                    updateTimeTimer.Stop();

                    SqlCommand cmd = new SqlCommand(
                        "INSERT INTO scores (Seconds) VALUES (" + (GAME_TIME / 1000 - seconds).ToString() + ")",
                        StartForm.Database
                        );
                    cmd.ExecuteNonQuery();
                    startForm.LoadData();
                    MessageBox.Show(
                        "Ai castigat, ti-au mai ramas " + seconds.ToString() + " secunde",
                        "Felicitari",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                    this.Dispose();
                    startForm.Show();
                }
            } else
            {
                selected2 = card;
                freeze.Value = true;
                freezeTimer.Start();
            }
        }

        private void Game_Resize(object sender, EventArgs e)
        {
            foreach (var card in cards)
                card.Invalidate();
        }

        private void Game_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Dispose();
            this.startForm.Show();
        }

        private void FreezeDone(object sender, EventArgs args)
        {
            freezeTimer.Stop();
            selected.ShowCard = !selected.ShowCard;
            selected2.ShowCard = !selected2.ShowCard;
            selected = null;
            selected2 = null;
            freeze.Value = false;
        }

        public void UpdateTime(object sender, EventArgs args)
        {
            seconds -= 1;            
            timeLabel.Text = "Timp ramas: " + seconds.ToString() + " secunde";
            if (seconds < 1)
            {
                freeze.Value = true;
                updateTimeTimer.Stop();
                MessageBox.Show(
                    "Timpul a expirat!",
                    "Ai pierdut!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Hand
                    );
                this.Dispose();
                startForm.Show();
            }
        }
    }
}
