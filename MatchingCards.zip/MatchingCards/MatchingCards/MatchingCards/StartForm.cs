﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatchingCards
{
    public partial class StartForm : Form
    {
        public static SqlConnection Database;

        public StartForm()
        {
            Database = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + Application.StartupPath + "\\Database.mdf;Integrated Security=True");
            Database.Open();
            InitializeComponent();
            LoadData();
        }

        public void LoadData()
        {
            scoreList.Items.Clear();
            SqlCommand command = new SqlCommand(
                "SELECT * FROM scores ORDER BY Seconds",
                Database
                );
            SqlDataReader reader = command.ExecuteReader();
            int top = 1;
            while (reader.Read())
            {
                int score = reader.GetInt32(1);
                scoreList.Items.Add(top.ToString() + ". " + score.ToString());
                top++;
            }
            reader.Close();
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            var gameForm = new Game(this);
            this.Hide();
            gameForm.Show();
        }
    }
}
