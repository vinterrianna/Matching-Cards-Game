﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatchingCards
{
    // https://stackoverflow.com/questions/1434840/c-copy-one-bool-to-another-by-ref-not-val
    public class BoolWrapper
    {
         public bool Value { get; set; }
         public BoolWrapper (bool value) { this.Value = value; }
    }
}
