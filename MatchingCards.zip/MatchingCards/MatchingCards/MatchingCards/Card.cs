﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace MatchingCards
{
    public partial class Card : UserControl
    {
        public delegate void SelectedEventHandler(Card card);
        public event SelectedEventHandler Selected;

        private static Image blank = Properties.Resources.blank;
        public static readonly string[] CARDS =
        {
            Application.StartupPath + "\\cards\\10_clubs_white.png",
            Application.StartupPath + "\\cards\\10_diamonds_white.png",
            Application.StartupPath + "\\cards\\2_clubs_white.png",
            Application.StartupPath + "\\cards\\2_hearts_white.png",
            Application.StartupPath + "\\cards\\3_spades_white.png",
            Application.StartupPath + "\\cards\\4_clubs_white.png",
            Application.StartupPath + "\\cards\\5_hearts_white.png",
            Application.StartupPath + "\\cards\\6_spades_white.png",
            Application.StartupPath + "\\cards\\7_diamonds_white.png",
            Application.StartupPath + "\\cards\\8_clubs_white.png",
            Application.StartupPath + "\\cards\\8_spades_white.png",
            Application.StartupPath + "\\cards\\9_diamonds_white.png",
            Application.StartupPath + "\\cards\\9_spades_white.png",
            Application.StartupPath + "\\cards\\8_diamonds_white.png",
            Application.StartupPath + "\\cards\\ace_clubs_white.png",
            Application.StartupPath + "\\cards\\ace_hearts_white.png",
            Application.StartupPath + "\\cards\\2_spades_white.png",
            Application.StartupPath + "\\cards\\4_diamonds_white.png",
            Application.StartupPath + "\\cards\\7_clubs_white.png",
        };
        private static float PADDING = 1;

        private Image cardImage;
        public Image CardImage
        {
            get { return cardImage; }
            set { this.cardImage = value; }
        }

        private bool showCard = false;
        public bool ShowCard
        {
            get { return showCard; }
            set
            {
                showCard = !showCard;
                this.Invalidate();
            }
        }

        private Tuple<int, int> coordinates;
        public Tuple<int, int> Coordinates
        {
            get { return coordinates; }
            set { coordinates = value; }
        }

        private bool disabled = false;
        public bool Disabled
        {
            get { return disabled; }
            set { this.disabled = value; }
        }

        private BoolWrapper freeze;

        public Card(
            Tuple<int, int> coordinates,
            BoolWrapper freeze
        ) {
            InitializeComponent();
            this.coordinates = coordinates;
            this.freeze = freeze;
        }

        private void Card_Paint(object sender, PaintEventArgs e)
        {
            Image image = showCard ? cardImage : blank;
            float ratio = (float) image.Width / (float) image.Height;
            float width, height;
            if (this.Width < this.Height)
            {
                width = this.Width;
                height = width / ratio;
            } else
            {
                height = this.Height;
                width = height * ratio;
            }

            e.Graphics.DrawImage(image, new RectangleF(
                (float) this.Width / 2 - width / 2, 
                (float) this.Height / 2 - height / 2, 
                width, height
            ));
        }

        private void Card_MouseUp(object sender, MouseEventArgs e)
        {
            if (disabled || freeze.Value)
                return;
            ShowCard = !ShowCard;
            Selected.Invoke(this);
        }
    }
}
